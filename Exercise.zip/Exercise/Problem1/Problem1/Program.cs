﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem1
{
    public class Point
    {
        public double x;  
        public double y;
    }

    public class Program
    {
        public static List<Point> FindClosestPoint(List<Point> allPoints, Point refpoint, int k)
        {
            List<Point> result = new List<Point>();

            //get all distances
            List<double> allDistances = new List<double>();

            for (int i = 0; i < allPoints.Count; i++)
            {
                allDistances.Add(Math.Sqrt(allPoints[i].x * allPoints[i].x + allPoints[i].y * allPoints[i].y));
            }

            // find all elements in allDistances until K
            // using quick-sort partition mechanism search for closest ones
            // starting search in allDistances beyond reference point
            // return the result

            return result;
        }

        static void Main(string[] args)
        {
            int[,] pattern = {{1 ,0, 1, 0, 0, 1,0},
                          {0 ,1, 0, 1, 1, 0,1},
                         {0, 0, 1, 0, 0, 1,0},
                         {0, 0, 0, 1, 1, 1,0},
                        {1, 1, 1, 0, 1, 0,1},
                        {0, 1, 0, 1, 0, 1,0},
                         };


        int[,] bitmap = { {0,1,0},
                         {1,0,1},
                         {0,1,0}
                        };

        BitMapMatching.FindPatternLocation(pattern, 6, bitmap, 3);

        }
    }
}
