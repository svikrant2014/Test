﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem1
{
    public class BitMapMatching
    {
        
        public static List<Point> FindPatternLocation(int[,] pattern, int rows1, int[,] bitmap, int rows2)
        {
            List<Point> res = new List<Point>();


            for (int i = 0; i < pattern.Length - bitmap.Length + 1; i++)
            {
                for (int k = 0; k < rows1 - rows2 + 1; k++)
                {
                    int count = 0;
                    for (int l = 0; l < bitmap.Length; l++)
                    {
                        for (int m = 0; m < rows2; m++)
                        {
                            // if the array difference = 0, it's a match and I can add the co-ordinates 
                            count += Math.Abs(bitmap[l, m] - pattern[i + l, k + m]);
                        }
                    }
                    if (count == 0)
                    {
                        Point p = new Point();
                        p.x = i; p.y = k;
                        res.Add(p);
                    }

                }
            }

            return res;
        }
    }
}
