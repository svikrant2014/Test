﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem1
{
    public class QuickSelect
    {
        public static double getkthelement(double[] A, int start, int end, int k)
        {
            //if (start >= end) return 1;

            int pindex = partition(A, start, end);

            int n = pindex - start + 1;

            if (k == n)
            {
                return A[pindex];
            }
            else if (k < n)
            {
                return getkthelement(A, start, pindex - 1, k);
            }
            else
            {
                return getkthelement(A, pindex + 1, end, k - n);
            }

            //Console.WriteLine(string.Join(",", A));
        }

        static int partition(double[] A, int start, int end)
        {
            double pivot = A[end];

            int pindex = start;

            for (int i = start; i <= end - 1; i++)
            {
                if (A[i] <= pivot)
                {
                    var tmp = A[i];
                    A[i] = A[pindex];
                    A[pindex] = tmp;

                    pindex++;
                }
            }

            var tmp1 = A[pindex];
            A[pindex] = A[end];
            A[end] = tmp1;

            return pindex;
        }
    }
}
