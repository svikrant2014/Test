﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem1
{
    public class BitMapMatching
    {
        /// <summary>
        /// runtime complexity = O(mn)
        /// </summary>
        /// <param name="pattern"></param>
        /// <param name="bitmap"></param>
        /// <returns></returns>
        public static List<Point> FindPatternLocation(int[,] pattern, int[,] bitmap)
        {
            List<Point> res = new List<Point>();
            int rows1 = pattern.GetLength(0), cols1 = pattern.GetLength(1);
            int rows2 = bitmap.GetLength(0), cols2 = bitmap.GetLength(1);


            for (int i = 0; i < rows1 - rows2 + 1; i++)
            {
                for (int k = 0; k < cols1-cols2 + 1; k++)
                {
                    int count = 0;
                    for (int l = 0; l < rows2; l++)
                    {
                        for (int m = 0; m < cols2; m++)
                        {
                            // if the array difference = 0, it's a match and I can add the co-ordinates 
                            count += Math.Abs(bitmap[l, m] - pattern[i + l, k + m]);
                        }
                    }
                    if (count == 0)
                    {
                        res.Add(new Point(i, k));
                    }

                }
            }

            return res;
        }
    }
}
