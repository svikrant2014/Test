﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem1
{
    public class Point
    {
        public double x { get; set; }
        public double y { get; set; }

        public Point(double x, double y)
        {
            this.x = x;
            this.y = y;
        }
    }

    public class Program
    {
        /// <summary>
        /// custom quick sort used to avoid sorting beyond k element
        /// runtime complexity will be equivalent to as of quick sort which is O(nlogn)
        /// </summary>
        /// <param name="allPoints"></param>
        /// <param name="center"></param>
        /// <param name="k"></param>
        /// <returns></returns>
        public static List<Point> FindClosestPoint(List<Point> allPoints, Point center, int k)
        {
            List<Point> result = new List<Point>();

            double a = center.x, b = center.y;

            //get all distances
            double[] allDistances = new double[allPoints.Count];

            for (int i = 0; i < allPoints.Count; i++)
            {
                allDistances[i] = (Math.Sqrt((allPoints[i].x - a) * (allPoints[i].x - a) + (allPoints[i].y - b) * (allPoints[i].y - b)));
            }

            //allDistances.Sort();

            // implementing custom sorting
            // as input can be very large compared to number of elements expetced in result
            double kmindistance = QuickSelect.getkthelement(allDistances, 0, allDistances.Length - 1, k);


            for (int i = 0; i < allPoints.Count; i++)
            {
                double dis = Math.Sqrt((allPoints[i].x - a) * (allPoints[i].x - a) + (allPoints[i].y - b) * (allPoints[i].y - b));

                if (dis <= kmindistance && result.Count < k)
                {
                    result.Add(new Point(allPoints[i].x, allPoints[i].y));
                }
            }

            return result;
        }

        static void Main(string[] args)
        {
            List<Point> allPoints = new List<Point>();

            allPoints.Add(new Point(2, 4));
            allPoints.Add(new Point(8, 12));
            allPoints.Add(new Point(9, 14));
            allPoints.Add(new Point(13, 18));
            allPoints.Add(new Point(0, 0));
            allPoints.Add(new Point(6, 16));
            allPoints.Add(new Point(5, 12));

           // FindClosestPoint(allPoints, new Point(4, 6), 3);



            int[,] pattern = {{1 ,0, 1, 0, 0, 1, 0},
                              {0 ,1, 0, 1, 1, 0, 1},
                              {0, 0, 1, 0, 0, 1, 0},
                              {0, 0, 0, 1, 0, 1, 0},
                              {1, 1, 1, 0, 1, 0, 1},
                              {0, 1, 0, 1, 0, 1, 0},
                         };


            int[,] bitmap = { {0,1,0},
                             {1,0,1},
                             {0,1,0}
                            };

        BitMapMatching.FindPatternLocation(pattern, bitmap);

        }
    }
}
